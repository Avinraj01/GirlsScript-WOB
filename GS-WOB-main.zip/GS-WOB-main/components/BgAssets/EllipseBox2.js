import React from "react";

function EllipseBox2() {
  return (
    <div>
      <div>
        <img
          src="https://user-images.githubusercontent.com/64256342/152584858-0c5b724e-e9d1-463c-8a5c-373def48921c.png"
          alt="ellipse-14"
        />
      </div>
    </div>
  );
}

export default EllipseBox2;
