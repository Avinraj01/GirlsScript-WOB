function EllipseBox() {
  return (
    <div>
      <div>
        <img
          src="https://user-images.githubusercontent.com/64256342/152584869-03187e72-436e-40eb-b778-4a8baf381417.png"
          alt="ellipse-15"
        />
      </div>
    </div>
  );
}

export default EllipseBox;
