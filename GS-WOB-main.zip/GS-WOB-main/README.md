# GS-WOB
Girlscript Winter of Blockchain developement
